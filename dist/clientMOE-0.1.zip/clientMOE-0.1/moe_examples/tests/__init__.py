# -*- coding: utf-8 -*-
"""Tests for the moe examples."""
