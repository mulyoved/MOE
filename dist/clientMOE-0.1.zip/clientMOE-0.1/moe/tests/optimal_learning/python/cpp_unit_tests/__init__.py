# -*- coding: utf-8 -*-
"""Single test case that invokes the C++ unit tests.

These live in a separate directory so it's easier to only invoke the Python cpp_wrappers tests without
hitting this (slower-running) suite.

"""
