# -*- coding: utf-8 -*-
"""Optimal learning tests."""
