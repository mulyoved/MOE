# -*- coding: utf-8 -*-
"""Tests for the MOE REST interface."""
